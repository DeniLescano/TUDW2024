while True:
    nombre = input("Por favor, ingresa tu nombre: ")
    if nombre == "":
        print("¡Debe ingresar un nombre!")
    else:
        print("El nombre ingresado es:", nombre)
        break
