texto = input("Ingrese un texto: ")
textInvertido = texto[::-1]
print("El texto al revés es:", textInvertido)
