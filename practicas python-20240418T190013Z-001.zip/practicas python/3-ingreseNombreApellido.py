nombre=""
apellido=""
while True:
    if nombre=="" :
        nombre=input('Por favor ingresa tu nombre: ')
    if apellido=="":
        apellido=input('Por favor ingresa tu apellido: ')

    if nombre== "" or apellido=="":
        print('¡Debe ingresar un nombre y un apellido')
    elif nombre=="":
        print('debe ingresar un nombre')
    elif apellido=="":
        print('debe ingresar un apellido')
    else:
        print('el nombre y apellido ingresado son: ',nombre, apellido)
        break
