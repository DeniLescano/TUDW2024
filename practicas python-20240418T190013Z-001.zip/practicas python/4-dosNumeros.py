n1=""
n2=""
while True:
    if n1=="" :
        n1=input('Por favor ingresa el primer numero: ')
    if n2=="":
        n2=input('Por favor ingresa el segundo numero: ')

    if n1== "" or n2=="" :
        print('¡Debe ingresar dos numeros')
    elif n1=="":
        print('debe ingresar el primer numero')
    elif n2=="":
        print('debe ingresar el segundo numero')
    else:
        n1=float(n1)
        n2=float(n2)
        print('la suma de los numeros' ,n1, ' y ',n2, 'es: ',float(n1+n2)   )
        break
    